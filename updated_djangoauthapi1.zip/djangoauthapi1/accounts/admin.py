# # from django.contrib import admin
# # from accounts.models import User
# # from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
#
# # class UserModelAdmin(BaseUserAdmin):
# #   # The fields to be used in displaying the User model.
# #   # These override the definitions on the base UserModelAdmin
# #   # that reference specific fields on auth.User.
# #   list_display = ('id', 'email', 'name', 'tc', 'is_admin')
# #   list_filter = ('is_admin',)
# #   fieldsets = (
# #       ('User Credentials', {'fields': ('email', 'password')}),
# #       ('Personal info', {'fields': ('name', 'tc')}),
# #       ('Permissions', {'fields': ('is_admin',)}),
# #   )
# #   # add_fieldsets is not a standard ModelAdmin attribute. UserModelAdmin
# #   # overrides get_fieldsets to use this attribute when creating a user.
# #   add_fieldsets = (
# #       (None, {
# #           'classes': ('wide',),
# #           'fields': ('email', 'name', 'tc', 'password1', 'password2'),
# #       }),
# #   )
# #   search_fields = ('email',)
# #   ordering = ('email', 'id')
# #   filter_horizontal = ()
#
#
# # # Now register the new UserModelAdmin...
# # admin.site.register(User, UserModelAdmin)
#
#
# from django.contrib import admin
# from accounts.models import User, Customer, Vendor, UserType, MenuGroupCategory,Category,Company
# from accounts.models import MenuGroup, MenuMaster, TaskMaster, UserTaskAccess, FieldMaster, TaskFieldMaster
#
# from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
#
#
# class UserModelAdmin(BaseUserAdmin):
#     # The fields to be used in displaying the User model.
#     # These override the definitions on the base UserModelAdmin
#     # that reference specific fields on auth.User.
#     list_display = ('id','company','username','email','name',
#                      'tc', 'note', 'is_published', 'gprname', 'seque', 'is_admin', 'is_staff', 'menugroup1', 'menugroup2', 'menugroup3', 'menugroup4')
#     list_filter = ('is_admin',)
#     fieldsets = (
#         ('User Credentials', {'fields': ('username', 'password')}),
#         ('Personal info', {
#          'fields': ('name', 'company', 'note', 'is_published', 'tc', 'gprname', 'seque')}),
#         ('Permissions', {'fields': ('is_admin', 'is_customer', 'is_vendor')}),
#     )
#     list_editable = ('is_published', 'menugroup1',
#                      'menugroup2', 'menugroup3', 'menugroup4',)
#     # add_fieldsets is not a standard ModelAdmin attribute. UserModelAdmin
#     # overrides get_fieldsets to use this attribute when creating a user.
#     add_fieldsets = (
#         (None, {
#             'classes': ('wide',),
#             'fields': ('usertype','company','name','username','email', 'password1', 'password2','tc', 'note', 'is_published', 'gprname', 'seque', 'menugroup1', 'menugroup2', 'menugroup3', 'menugroup4'),
#         }),
#     )
#     search_fields = ('email',)
#     ordering = ('email', 'id')
#     filter_horizontal = ()
#
#
#
# # Now register the new UserModelAdmin...
# admin.site.register(User, UserModelAdmin)
# admin.site.register(MenuGroup)
# admin.site.register(MenuMaster)
# admin.site.register(TaskMaster)
# admin.site.register(UserTaskAccess)
# admin.site.register(FieldMaster)
# admin.site.register(TaskFieldMaster)
# admin.site.register(Customer)
# admin.site.register(Vendor)
# admin.site.register(MenuGroupCategory)
# admin.site.register(UserType)
# # admin.site.register(Field_Master)
# admin.site.register(Category)
# admin.site.register(Company)



# from django.contrib import admin
# from accounts.models import User
# from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

# class UserModelAdmin(BaseUserAdmin):
#   # The fields to be used in displaying the User model.
#   # These override the definitions on the base UserModelAdmin
#   # that reference specific fields on auth.User.
#   list_display = ('id', 'email', 'name', 'tc', 'is_admin')
#   list_filter = ('is_admin',)
#   fieldsets = (
#       ('User Credentials', {'fields': ('email', 'password')}),
#       ('Personal info', {'fields': ('name', 'tc')}),
#       ('Permissions', {'fields': ('is_admin',)}),
#   )
#   # add_fieldsets is not a standard ModelAdmin attribute. UserModelAdmin
#   # overrides get_fieldsets to use this attribute when creating a user.
#   add_fieldsets = (
#       (None, {
#           'classes': ('wide',),
#           'fields': ('email', 'name', 'tc', 'password1', 'password2'),
#       }),
#   )
#   search_fields = ('email',)
#   ordering = ('email', 'id')
#   filter_horizontal = ()


# # Now register the new UserModelAdmin...
# admin.site.register(User, UserModelAdmin)


from django.contrib import admin
from accounts.models import AddCompany, AddUser, AddUserCategory, Adminaccess, UserMaster
from accounts.models import MenuGroupMaster, MenuMaster, TaskMaster, UserTaskAccess, FieldMaster, TaskFieldMaster, Last_update_task, Last_update_user

from django.contrib.auth.admin import UserAdmin as BaseUserAdmin


# class UserModelAdmin(BaseUserAdmin):
#     # The fields to be used in displaying the User model.
#     # These override the definitions on the base UserModelAdmin
#     # that reference specific fields on auth.User.
#     list_display = ('company', 'user', 'username', 'email', 'user_category',
#                     'inactive', 'note', 'Adminaccess', 'is_admin', 'last_update_user','last_update_date','last_update_time', 'last_update_task','last_update_ip')
#     list_filter = ('is_admin',)
#     fieldsets = (
#         ('User Credentials', {'fields': ('username', 'password')}),
#         ('Personal info', {
#          'fields': ('email', 'inactive', 'note')}),
#         ('Permissions', {'fields': ('is_admin',)}),
#     )
#     list_editable = ('username', 'note',)
#     # add_fieldsets is not a standard ModelAdmin attribute. UserModelAdmin
#     # overrides get_fieldsets to use this attribute when creating a user.
#     add_fieldsets = (
#         (None, {
#             'classes': ('wide',),
#             'fields': ('company', 'user', 'username', 'password1', 'password2', 'email', 'user_category', 'inactive', 'note', 'Adminaccess', 'last_update_user', 'last_update_task','last_update_ip'),
#         }),
#     )
#     search_fields = ('email',)
#     ordering = ('email', 'id')
#     filter_horizontal = ()


# class MenuGroupMasterAdmin(admin.ModelAdmin):
#     list_display = ['group_name', 'sequence', 'inactive', 'note']


# class MenuMasterAdmin(admin.ModelAdmin):
#     list_display = ['group_name', 'menu_name', 'task']


# class TaskMasterAdmin(admin.ModelAdmin):
#     list_display = ['task', 'description', 'pyname', 'inactive',
#                     'note', 'last_update_user', 'last_update_task', 'last_update_ip']


# class UserTaskAccessAdmin(admin.ModelAdmin):
#     list_display = ['company', 'user', 'task', 'inactive',
#                     'note', 'view_access', 'add_access', 'edit_access', 'delete_access', 'inactive_access', 'last_update_user', 'last_update_task', 'last_update_ip']


# class FieldMasterAdmin(admin.ModelAdmin):
#     list_display = ['field', 'placeholder_message', 'error_message', 'inactive',
#                     'note', 'last_update_user', 'last_update_task', 'last_update_ip']


# class TaskFieldMasterAdmin(admin.ModelAdmin):
#     list_display = ['company', 'user', 'task', 'field', 'restricted', 'inactive',
#                     'note', 'last_update_user', 'last_update_task', 'last_update_ip']

# # Now register the new UserModelAdmin...


# admin.site.register(UserMaster, UserModelAdmin)
# admin.site.register(MenuGroupMaster, MenuGroupMasterAdmin)
# admin.site.register(MenuMaster, MenuMasterAdmin)
# admin.site.register(TaskMaster, TaskMasterAdmin)
# admin.site.register(UserTaskAccess, UserTaskAccessAdmin)
# admin.site.register(FieldMaster, FieldMasterAdmin)
# admin.site.register(TaskFieldMaster, TaskFieldMasterAdmin)

# admin.site.register(Last_update_user)
# admin.site.register(Last_update_task)
# # admin.site.register(UserType)
# # admin.site.register(Field_Master)
# admin.site.register(AddUserCategory)
# admin.site.register(AddCompany)
# admin.site.register(AddUser)
# admin.site.register(Adminaccess)



class UserModelAdmin(BaseUserAdmin):
    # The fields to be used in displaying the User model.
    # These override the definitions on the base UserModelAdmin
    # that reference specific fields on auth.User.
    list_display = ('company', 'user', 'username', 'email', 'user_category',
                    'inactive', 'note', 'is_admin', 'last_update_user','last_update_date','last_update_time', 'last_update_task','last_update_ip')
    list_filter = ('is_admin',)
    fieldsets = (
        ('User Credentials', {'fields': ('username', 'password')}),
        ('Personal info', {
         'fields': ('email', 'inactive', 'note')}),
        ('Permissions', {'fields': ('is_admin',)}),
    )
    list_editable = ('username', 'note',)
    # add_fieldsets is not a standard ModelAdmin attribute. UserModelAdmin
    # overrides get_fieldsets to use this attribute when creating a user.
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('company', 'user', 'username', 'password1', 'password2', 'email', 'user_category', 'inactive', 'note', 'menugroup1', 'menugroup2', 'menugroup3', 'menugroup4','last_update_user', 'last_update_task','last_update_ip'),
        }),
    )
    search_fields = ('email',)
    ordering = ('email', 'id')
    filter_horizontal = ()


class MenuGroupMasterAdmin(admin.ModelAdmin):
    list_display = ['group_name', 'sequence', 'inactive', 'note']


class MenuMasterAdmin(admin.ModelAdmin):
    list_display = ['group_name', 'menu_name', 'task']


class TaskMasterAdmin(admin.ModelAdmin):
    list_display = ['task', 'description', 'pyname','inactive','note']


class FieldMasterAdmin(admin.ModelAdmin):
    list_display = ['field', 'placeholder_message', 'error_message', 'inactive',
                    'note']


class TaskFieldMasterAdmin(admin.ModelAdmin):
    list_display = ['field', 'restricted', 'inactive',
                    'note', 'last_update_user', 'last_update_task', 'last_update_ip']


class UserTaskAccessAdmin(admin.ModelAdmin):
    list_display = ['company', 'user', 'task', 'inactive',
                    'note', 'view_access', 'add_access', 'edit_access', 'delete_access', 'inactive_access', 'last_update_user', 'last_update_task', 'last_update_ip']


# Now register the new UserModelAdmin...


admin.site.register(UserMaster, UserModelAdmin)
admin.site.register(MenuGroupMaster, MenuGroupMasterAdmin)
admin.site.register(MenuMaster, MenuMasterAdmin)
admin.site.register(TaskMaster, TaskMasterAdmin)
admin.site.register(UserTaskAccess, UserTaskAccessAdmin)
admin.site.register(FieldMaster, FieldMasterAdmin)
admin.site.register(TaskFieldMaster, TaskFieldMasterAdmin)

# admin.site.register(UserType)
# admin.site.register(Field_Master)

# admin.site.register(AddUserCategory)
# admin.site.register(AddCompany)
# admin.site.register(AddUser)
# admin.site.register(Adminaccess)
