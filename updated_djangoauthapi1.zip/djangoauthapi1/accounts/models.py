# from django.db import models
# from django.contrib.auth.models import BaseUserManager,AbstractBaseUser

# #  Custom User Manager
# class UserManager(BaseUserManager):
#   def create_user(self, email, name, tc, password=None, password2=None):
#       """
#       Creates and saves a User with the given email, name, tc and password.
#       """
#       if not email:
#           raise ValueError('User must have an email address')

#       user = self.model(
#           email=self.normalize_email(email),
#           name=name,
#           tc=tc,
#       )

#       user.set_password(password)
#       user.save(using=self._db)
#       return user

#   def create_superuser(self, email, name, tc, password=None):
#       """
#       Creates and saves a superuser with the given email, name, tc and password.
#       """
#       user = self.create_user(
#           email,
#           password=password,
#           name=name,
#           tc=tc,
#       )
#       user.is_admin = True
#       user.save(using=self._db)
#       return user

# #  Custom User Model
# class User(AbstractBaseUser):
#   email = models.EmailField(
#       verbose_name='Email',
#       max_length=255,
#       unique=True,
#   )
#   name = models.CharField(max_length=200)
#   tc = models.BooleanField()
#   is_active = models.BooleanField(default=True)
#   is_admin = models.BooleanField(default=False)
#   created_at = models.DateTimeField(auto_now_add=True)
#   updated_at = models.DateTimeField(auto_now=True)

#   objects = UserManager()

#   USERNAME_FIELD = 'email'
#   REQUIRED_FIELDS = ['name', 'tc']

#   def __str__(self):
#       return self.email

#   def has_perm(self, perm, obj=None):
#       "Does the user have a specific permission?"
#       # Simplest possible answer: Yes, always
#       return self.is_admin

#   def has_module_perms(self, app_label):
#       "Does the user have permissions to view the app `app_label`?"
#       # Simplest possible answer: Yes, always
#       return True

#   @property
#   def is_staff(self):
#       "Is the user a member of staff?"
#       # Simplest possible answer: All admins are staff
#       return self.is_admin


# New...............


from django.db import models
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser, PermissionsMixin
from django.contrib.auth.models import User
from datetime import date
from  datetime import time
from datetime import datetime
#  Custom User Manager


class AddCompany(models.Model):
    name = models.CharField(max_length=120)
    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class AddUser(models.Model):
    name = models.CharField(max_length=120)
    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class AddUserCategory(models.Model):
    name = models.CharField(max_length=120)
    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Adminaccess(models.Model):
    YES = 1
    NO = 2
    ADMIN_CHOICES = (

        (YES, 'TRUE'),
        (NO, 'FALSE')
    )

    id = models.PositiveBigIntegerField(
        choices=ADMIN_CHOICES, primary_key=True)

    def __str__(self):
        return self.get_id_display()


class Last_update_user(models.Model):
    XYZ = 1
    COMP1 = 2
    LAST_UPDATE_USER_CHOICES = (
        (XYZ, 'XYZ'),
        (COMP1, 'COMP1')
    )

    id = models.PositiveBigIntegerField(
        choices=LAST_UPDATE_USER_CHOICES, primary_key=True)

    def __str__(self):
        return self.get_id_display()


class Last_update_task(models.Model):
    TASK_MASTER = 1
    FIELD_MASTER = 2
    TASK_FIELD_MASTER = 3
    User_Master = 4
    USER_TASK_MASTER = 5
    OTHER_TASK2 = 6
    OTHER_TASK3 = 7

    LAST_UPDATE_TASK_CHOICES = (

        (TASK_MASTER, 'TASK_MASTER'),
        (FIELD_MASTER, 'FIELD_MASTER'),
        (TASK_FIELD_MASTER, 'TASK_FIELD_MASTER'),
        (User_Master, 'User_Master'),
        (USER_TASK_MASTER, 'USER_TASK_MASTER'),
        (OTHER_TASK2, 'OTHER_TASK2'),
        (OTHER_TASK3, 'OTHER_TASK3')
    )

    id = models.PositiveBigIntegerField(
        choices=LAST_UPDATE_TASK_CHOICES, primary_key=True)

    def __str__(self):
        return self.get_id_display()

class UserManager(BaseUserManager):
    def create_user(self, email, username, user, company, note, menugroup1, menugroup2, menugroup3, menugroup4, is_published, is_active,user_category,adminaccess,last_update_user, last_update_task, last_update_ip,password=None, password2=None):
        """
        Creates and saves a User with the given email, name, tc and password.
        """
        if not username:
            raise ValueError('User must have an Username')

        user = self.model(
            username=self.normalize_email(username),
            user=user,
            # usertype=usertype,
            company=company,
            email=email,
            note=note,
            is_published=is_published,
            menugroup1=menugroup1,
            menugroup2=menugroup2,
            menugroup3=menugroup3,
            menugroup4=menugroup4,
            user_category=user_category,
            adminaccess=adminaccess,
            last_update_user=last_update_user,
            last_update_task=last_update_task,
            last_update_ip=last_update_ip,
            is_active=is_active,

        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, username, user, company, note, menugroup1, menugroup2, menugroup3, menugroup4, is_published, is_active,user_category,adminaccess,last_update_user, last_update_task, last_update_ip, password=None, **extra_fields):
        """
        Creates and saves a superuser with the given email, name, tc and password.
        """
        user = self.create_user(
            password=password,
            username=username,
            user=user,
            # usertype=usertype,
            company=company,
            email=email,
            note=note,
            is_published=is_published,
            menugroup1=menugroup1,
            menugroup2=menugroup2,
            menugroup3=menugroup3,
            menugroup4=menugroup4,
            user_category=user_category,
            adminaccess=adminaccess,
            last_update_user=last_update_user,
            last_update_task=last_update_task,
            last_update_ip=last_update_ip,
            is_active=is_active,
            **extra_fields,
        )
        user.is_admin = True
        user.save(using=self._db)
        return user

#  Custom User Model



class UserMaster(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField(
        verbose_name='Email',
        max_length=255,
        unique=True,
    ) 
    company = models.CharField(max_length=100)
    user = models.CharField(max_length=200)
    username = models.CharField(max_length=200, unique=True)
    name = models.CharField(max_length=200)
    user_category = models.CharField(max_length=100)
    adminaccess = models.CharField(max_length=100)
    menugroup1 = models.CharField(max_length=100, blank=True, null=True)
    menugroup2 = models.CharField(max_length=100, blank=True, null=True)
    menugroup3 = models.CharField(max_length=100, blank=True, null=True)
    menugroup4 = models.CharField(max_length=100, blank=True, null=True)
    company = models.CharField(max_length=100)
    note = models.CharField(max_length=100, blank=True,null=True)
    password = models.CharField(max_length=100)
    inactive = models.BooleanField()
    last_update_user = models.CharField(max_length=100)
    last_update_task = models.CharField(max_length=190)
    last_update_ip = models.CharField(max_length=120)    
    last_update_date = models.DateTimeField(auto_now_add=True)
    last_update_time = models.DateTimeField(auto_now=True)
    is_published = models.BooleanField(default=True)
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=True)

    objects = UserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email', 'user', 'company', 'note','is_active',
                       'is_published', 'menugroup1', 'menugroup2', 'menugroup3', 'menugroup4',
    'last_update_user','last_update_task','last_update_ip','user_category','adminaccess']

    def __str__(self):
        # return self.get_username
        return self.email

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return self.is_admin

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    @property
    def is_staff(self):
        "Is the user a member of staff?"
        # Simplest possible answer: All admins are staff
        return self.is_admin

class MenuGroupMaster(models.Model):
    group_name = models.CharField(max_length=100)
    sequence = models.CharField(max_length=10)
    inactive = models.BooleanField(null=True)
    note = models.CharField(max_length=150,blank=True)

    
    def __str__(self):
        return self.group_name

class TaskMaster(models.Model):
    # task = models.ForeignKey(MenuMaster, on_delete=models.CASCADE)
    task = models.CharField(max_length=100)
    description = models.CharField(max_length=100)
    pyname = models.CharField(max_length=30)
    inactive = models.BooleanField(null=True)
    note = models.CharField(max_length=150,blank=True)
    last_update_user = models.CharField(max_length=100,default=True)
    last_update_task = models.CharField(max_length=190,default=True)
    last_update_ip = models.CharField(max_length=120,default=True)    
    # last_update_date = models.DateTimeField(auto_now_add=True)
    # last_update_time = models.DateTimeField(auto_now=True)

    
    def __str__(self):
        return self.task
    

class MenuMaster(models.Model):
    # group_name = models.ForeignKey(MenuGroupMaster, on_delete=models.CASCADE)
    group_name = models.CharField(max_length=100)    
    menu_name = models.CharField(max_length=120)
    task = models.ForeignKey(TaskMaster, on_delete=models.CASCADE)
    task = models.CharField(max_length=100)

    def __str__(self):
        return self.menu_name


class AddCompany(models.Model):
    name = models.CharField(max_length=120)
    # desc = models.CharField(max_length=100)
    def __str__(self):
        return self.name

class AddUser(models.Model):
    name = models.CharField(max_length=120)
    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class AddUserCategory(models.Model):
    name = models.CharField(max_length=120)
    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Adminaccess(models.Model):
    YES = 1
    NO = 2
    ADMIN_CHOICES = (

        (YES, 'TRUE'),
        (NO, 'FALSE')
    )

    id = models.PositiveBigIntegerField(
        choices=ADMIN_CHOICES, primary_key=True)

    def __str__(self):
        return self.get_id_display()



class UserTaskAccess(models.Model):
    company = models.ForeignKey(AddCompany, on_delete=models.CASCADE)
    user = models.ForeignKey(AddUser, on_delete=models.CASCADE)
    task = models.ForeignKey(TaskMaster, on_delete=models.CASCADE)
    inactive = models.BooleanField(null=True)
    note = models.CharField(max_length=150,blank=True)
    view_access = models.BooleanField()
    add_access = models.BooleanField()
    edit_access = models.BooleanField()
    delete_access = models.BooleanField()
    inactive_access = models.BooleanField()
    last_update_user = models.CharField(max_length=100)
    last_update_task = models.CharField(max_length=190)
    last_update_ip = models.CharField(max_length=120)    
    last_update_date = models.DateTimeField(auto_now_add=True)
    last_update_time = models.DateTimeField(auto_now=True)

    
    def __str__(self):
        return self.note


class FieldMaster(models.Model):
    # user = models.ForeignKey(UserMaster, on_delete=models.CASCADE, blank=True, null=True)
    field = models.CharField(max_length=150)
    placeholder_message = models.CharField(max_length=100,blank=True)
    error_message = models.CharField(max_length=100,blank=True)
    inactive = models.BooleanField(null=True)
    note = models.CharField(max_length=150,blank=True)
    last_update_user = models.CharField(max_length=100,default=True)
    last_update_task = models.CharField(max_length=190,default=True)
    last_update_ip = models.CharField(max_length=120,default=True)    
    # last_update_date = models.DateTimeField(auto_now_add=True)
    # last_update_time = models.DateTimeField(auto_now=True)

    
    def __str__(self):
        return self.field


class TaskFieldMaster(models.Model):
    company = models.ForeignKey(AddCompany, on_delete=models.CASCADE,default=None)
    user = models.ForeignKey(AddUser, on_delete=models.CASCADE,default=None)
    task = models.ForeignKey(TaskMaster, on_delete=models.CASCADE,default=None)
    field = models.ForeignKey(FieldMaster, on_delete=models.CASCADE)
    restricted = models.BooleanField()
    inactive = models.BooleanField(null=True)
    note = models.CharField(max_length=150,blank=True)
    last_update_user = models.CharField(max_length=100)
    last_update_task = models.CharField(max_length=190)
    last_update_ip = models.CharField(max_length=120)    
    last_update_date = models.DateTimeField(auto_now_add=True)
    last_update_time = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.note



