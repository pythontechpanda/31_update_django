from rest_framework.response import Response
from rest_framework import status
from rest_framework import permissions
from rest_framework.views import APIView
from accounts.serializers import *
from django.contrib.auth import authenticate
from accounts.renderers import UserRenderer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from .models import *
from django.http import Http404
from datetime import date
import socket
from django.shortcuts import render, HttpResponse
from rest_framework.filters import SearchFilter
from rest_framework.generics import ListAPIView

# Generate Token Manually


def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }


class UserRegistrationView(APIView):
    # renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        serializer = UserRegistrationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()
        token = get_tokens_for_user(user)
        return Response({'token': token, 'msg': 'Registration Successful'}, status=status.HTTP_201_CREATED)


class UserLoginView(APIView):
    # renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        serializer = UserLoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        # email = serializer.data.get('email')
        username = serializer.data.get('username')
        password = serializer.data.get('password')
        user = authenticate(username=username, password=password)
        if user is not None:
            token = get_tokens_for_user(user)
            return Response({'token': token, 'msg': 'Login Success'}, status=status.HTTP_200_OK)
        else:
            return Response({'errors': {'non_field_errors': ['Username or Password is not Valid']}}, status=status.HTTP_404_NOT_FOUND)


class UserProfileView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        serializer = UserProfileSerializer(request.user)
        return Response(serializer.data, status=status.HTTP_200_OK)


class UserChangePasswordView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        serializer = UserChangePasswordSerializer(
            data=request.data, context={'user': request.user})
        serializer.is_valid(raise_exception=True)
        return Response({'msg': 'Password Changed Successfully'}, status=status.HTTP_200_OK)


class SendPasswordResetEmailView(APIView):
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        serializer = SendPasswordResetEmailSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        return Response({'msg': 'Password Reset link send. Please check your Email'}, status=status.HTTP_200_OK)


class UserPasswordResetView(APIView):
    renderer_classes = [UserRenderer]

    def post(self, request, uid, token, format=None):
        serializer = UserPasswordResetSerializer(
            data=request.data, context={'uid': uid, 'token': token})
        serializer.is_valid(raise_exception=True)
        return Response({'msg': 'Password Reset Successfully'}, status=status.HTTP_200_OK)


# Company views opertions here.................

class CreateMenuGroupMasterView(APIView):

    def post(self, request, format=None):
        serializer = MenuGroupMasterSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            # token= get_tokens_for_user(user)
            return Response({'msg': 'Saved', 'status': 'success', 'menugroup': serializer.data}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    # renderer_classes =[UserRenderer]
    # def get(self, request, pk=None, format=None):
    #     id = pk
    #     if id is not None:
    #         prod = MenuGroup.objects.get(id=id)
    #         serializer = MenuGroupMasterSerializer(prod)
    #         return Response(serializer.data)
    #     prod = MenuGroup.objects.all()
    #     serializer = MenuGroupMasterSerializer(prod, many=True)
    #     return Response(serializer.data)

    def get(self, request, format=None):
        prod = MenuGroupMaster.objects.all()
        serializer = MenuGroupMasterSerializer(prod, many=True)
        return Response({'status': 'success', 'manugroup': serializer.data}, status=status.HTTP_200_OK)


class UpdateMenuGroupMasterView(APIView):
    def get_object(self, pk):
        try:
            return MenuGroupMaster.objects.get(pk=pk)
        except MenuGroupMaster.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        menugrp = self.get_object(pk)
        serializer = MenuGroupMasterSerializer(menugrp)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk, format=None):
        menugrp = self.get_object(pk)
        serializer = MenuGroupMasterSerializer(menugrp, data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            return Response({'msg': 'changed'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        menugrp = self.get_object(pk)
        menugrp.delete()
        return Response({'msg': 'Deleted'}, status=status.HTTP_204_NO_CONTENT)


class CreateMenuMasterView(APIView):
    # renderer_classes=[UserRenderer]

    def get(self, request, pk=None, format=None):
        id = pk
        if id is not None:
            prod = MenuMaster.objects.get(id=id)
            serializer = MenuMasterSerializer(prod)
            return Response(serializer.data)
        prod = MenuMaster.objects.all()
        serializer = MenuMasterSerializer(prod, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = MenuMasterSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            return Response({'msg': 'Created'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UpdateMenuMasterView(APIView):
    def get_object(self, pk):
        try:
            return MenuMaster.objects.get(pk=pk)
        except MenuMaster.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        menumaster = self.get_object(pk)
        serializer = MenuMasterSerializer(menumaster)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk, format=None):
        menumaster = self.get_object(pk)
        serializer = MenuMasterSerializer(menumaster, data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            return Response({'msg': 'Changed'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        menumaster = self.get_object(pk)
        menumaster.delete()
        return Response({'msg': 'Deleted'}, status=status.HTTP_204_NO_CONTENT)


lastip = socket.gethostbyname(socket.gethostname())
# print(type(lastip))


class CreateTaskMasterView(APIView):
    # renderer_classes=[UserRenderer]
    def get(self, request, pk=None, format=None):
        id = pk
        if id is not None:
            prod = TaskMaster.objects.get(id=id)
            serializer = TaskMasterSerializer(prod)
            return Response(serializer.data)
        prod = TaskMaster.objects.all()
        serializer = TaskMasterSerializer(prod, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = TaskMasterSerializer(data=request.data)
        print(serializer)

        if serializer.is_valid(raise_exception=True):
            lastip = socket.gethostbyname(socket.gethostname())
            serializer.lastupdateip = lastip
            user = serializer.save()

            return Response({'msg': 'Created'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UpdateTaskMasterView(APIView):
    # permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return TaskMaster.objects.get(pk=pk)
        except TaskMaster.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        taskmaster = self.get_object(pk)
        serializer = TaskMasterSerializer(taskmaster)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk, format=None):
        taskmaster = self.get_object(pk)
        serializer = TaskMasterSerializer(taskmaster, data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            return Response({'msg': 'Changed'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        taskmaster = self.get_object(pk)
        taskmaster.delete()
        return Response({'msg': 'Deleted'}, status=status.HTTP_204_NO_CONTENT)


# class CreateUserTaskAccessView(APIView):
#     # renderer_classes=[UserRenderer]

#     def get(self, request, pk=None, format=None):
#         id = pk
#         if id is not None:
#             prod = UserTaskAccess.objects.get(id=id)
#             serializer = UserTaskAccessSerializer(prod)
#             return Response(serializer.data)
#         prod = UserTaskAccess.objects.all()
#         serializer = UserTaskAccessSerializer(prod, many=True)
#         return Response(serializer.data)

#     def post(self, request, format=None):
#         serializer = UserTaskAccessSerializer(data=request.data)
#         # print(serializer.description)
#         # lastip = socket.gethostbyname(socket.gethostbyname())
#         if serializer.is_valid(raise_exception=True):
#             # print(serializer.description)
#             user = serializer.save()
#             print(user.taskacc)
#             return Response({'msg': 'Created'}, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# class UpdateUserTaskAccessView(APIView):
#     # permission_classes = [IsAuthenticated]

#     def get_object(self, pk):
#         try:
#             return UserTaskAccess.objects.get(pk=pk)
#         except UserTaskAccess.DoesNotExist:
#             raise Http404

#     def get(self, request, pk, format=None):
#         usertaskaccess = self.get_object(pk)
#         serializer = UserTaskAccessSerializer(usertaskaccess)
#         return Response(serializer.data, status=status.HTTP_200_OK)

#     def put(self, request, pk, format=None):
#         usertaskaccess = self.get_object(pk)
#         serializer = UserTaskAccessSerializer(
#             usertaskaccess, data=request.data)
#         if serializer.is_valid(raise_exception=True):
#             user = serializer.save()
#             return Response({'msg': 'changed'}, status=status.HTTP_201_CREATED)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#     def delete(self, request, pk, format=None):
#         usertaskaccess = self.get_object(pk)
#         usertaskaccess.delete()
#         return Response({'msg': 'Deleted'}, status=status.HTTP_204_NO_CONTENT)

# Final.....


# class CreateUserTaskAccessView(APIView):
#     # add permission to check if user is authenticated
#     # permission_classes = [permissions.IsAuthenticated]
#
#     # 1. List all
#     def get(self, request, *args, **kwargs):
#         '''
#         List all the todo items for given requested user
#         '''
#         todos = UserTaskAccess.objects.filter(user=request.user.id)
#         serializer = UserTaskAccessSerializer(todos, many=True)
#         return Response(serializer.data, status=status.HTTP_200_OK)
#
#     # 2. Create
#     def post(self, request, *args, **kwargs):
#         '''
#         Create the Todo with given todo data
#         '''
#
#         data = {
#
#             'inactive': request.data.get('inactive'),
#             'note': request.data.get('note'),
#             'notetaskacc': request.data.get('notetaskacc'),
#             'view_access': request.data.get('view_access'),
#             'add_access': request.data.get('add_access'),
#             'edit_access': request.data.get('edit_access'),
#             'delete_access': request.data.get('delete_access'),
#             'inactive_access': request.data.get('inactive_access'),
#             'last_update_ip': request.data.get('last_update_ip'),
#
#             'user': request.user.id
#         }
#
#         serializer = UserTaskAccessSerializer(data=data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response({'msg': 'Created'}, serializer.data, status=status.HTTP_201_CREATED)
#
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#
#
# class UpdateUserTaskAccessView(APIView):
#     # add permission to check if user is authenticated
#     # permission_classes = [IsAuthenticated]
#
#     def get_object(self, todo_id, user_id):
#         '''
#         Helper method to get the object with given todo_id, and user_id
#         '''
#         try:
#             return UserTaskAccess.objects.get(id=todo_id, user=user_id)
#         except UserTaskAccess.DoesNotExist:
#             return None
#
#     # 3. Retrieve
#     def get(self, request, todo_id, *args, **kwargs):
#         '''
#         Retrieves the Todo with given todo_id
#         '''
#         todo_instance = self.get_object(todo_id, request.user.id)
#         if not todo_instance:
#             return Response(
#                 {"res": "Object with todo id does not exists"},
#                 status=status.HTTP_400_BAD_REQUEST
#             )
#
#         serializer = UserTaskAccessSerializer(todo_instance)
#         return Response(serializer.data, status=status.HTTP_200_OK)
#
#     # 4. Update
#     def put(self, request, todo_id, *args, **kwargs):
#         '''
#         Updates the todo item with given todo_id if exists
#         '''
#         todo_instance = self.get_object(todo_id, request.user.id)
#         if not todo_instance:
#             return Response(
#                 {"res": "Object with todo id does not exists"},
#                 status=status.HTTP_400_BAD_REQUEST
#             )
#
#         data = {
#             'inactive': request.data.get('inactive'),
#             'note': request.data.get('note'),
#             'notetaskacc': request.data.get('notetaskacc'),
#             'view_access': request.data.get('view_access'),
#             'add_access': request.data.get('add_access'),
#             'edit_access': request.data.get('edit_access'),
#             'delete_access': request.data.get('delete_access'),
#             'inactive_access': request.data.get('inactive_access'),
#             'last_update_ip': request.data.get('last_update_ip'),
#
#             'user': request.user.id
#         }
#         serializer = UserTaskAccessSerializer(
#             instance=todo_instance, data=data, partial=True)
#         if serializer.is_valid():
#             serializer.save()
#             return Response({'msg': 'Changed'}, serializer.data, status=status.HTTP_200_OK)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
#
#     # 5. Delete
#     def delete(self, request, todo_id, *args, **kwargs):
#         '''
#         Deletes the todo item with given todo_id if exists
#         '''
#         todo_instance = self.get_object(todo_id, request.user.id)
#         if not todo_instance:
#             return Response(
#                 {"res": "Object with todo id does not exists"},
#                 status=status.HTTP_400_BAD_REQUEST
#             )
#         todo_instance.delete()
#         return Response(
#             {'msg': 'Deleted'},
#             status=status.HTTP_200_OK
#         )


class CreateUserTaskAccessView(APIView):
    # renderer_classes=[UserRenderer]
    def get(self, request, pk=None, format=None):
        id = pk
        if id is not None:
            prod = UserTaskAccess.objects.get(id=id)
            serializer = UserTaskAccessSerializer(prod)
            return Response(serializer.data)
        prod = UserTaskAccess.objects.all()
        serializer = UserTaskAccessSerializer(prod, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = UserTaskAccessSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            return Response({'msg': 'Created'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UpdateUserTaskAccessView(APIView):
    # permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return UserTaskAccess.objects.get(pk=pk)
        except UserTaskAccess.DoesNotExist:
            return Http404

    def get(self, request, pk, format=None):
        taskfieldmaster = self.get_object(pk)
        serializer = UserTaskAccessSerializer(taskfieldmaster, data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk, format=None):
        taskfieldmaster = self.get_object(pk)
        serializer = UserTaskAccessSerializer(
            taskfieldmaster, data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            return Response({'msg': 'Chenged'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        taskfieldmaster = self.get_object(pk)
        taskfieldmaster.delete()
        return Response({'msg': 'Delete'}, status=status.HTTP_204_NO_CONTENT)

from django_filters.rest_framework import DjangoFilterBackend
# For Filter..

class FieldMasterList(ListAPIView):
    queryset = FieldMaster.objects.all()
    serializer_class= FieldMasterSerializer
    filter_backends =[DjangoFilterBackend]
    filterset_fields=['field','placeholder_message','error_message','note']
    # search_fileds=['field']


class TaskMasterList(ListAPIView):
    queryset = TaskMaster.objects.all()
    serializer_class= TaskMasterSerializer
    filter_backends =[DjangoFilterBackend]
    filterset_fields=['task','description','pyname']
    # search_fileds=['field']



class CreateFieldMasterView(APIView):
    # renderer_classes=[UserRenderer]
    def get(self, request, pk=None, format=None):
        id = pk
        if id is not None:
            prod = FieldMaster.objects.get(id=id)
            serializer = FieldMasterSerializer(prod)
            return Response(serializer.data)
        prod = FieldMaster.objects.all()
        serializer = FieldMasterSerializer(prod, many=True)

        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = FieldMasterSerializer(data=request.data)
        print(serializer)

        if serializer.is_valid(raise_exception=True):
            lastip = socket.gethostbyname(socket.gethostname())
            serializer.lastupdateip = lastip
            user = serializer.save()

            return Response({'msg': 'Created'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UpdateFieldMasterView(APIView):
    # permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return FieldMaster.objects.get(pk=pk)
        except FieldMaster.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        taskmaster = self.get_object(pk)
        serializer = FieldMasterSerializer(taskmaster)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk, format=None):
        taskmaster = self.get_object(pk)
        serializer = FieldMasterSerializer(taskmaster, data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            return Response({'msg': 'Changed'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        taskmaster = self.get_object(pk)
        taskmaster.delete()
        return Response({'msg': 'Deleted'}, status=status.HTTP_204_NO_CONTENT)


class CreateTaskFieldMasterView(APIView):
    # renderer_classes=[UserRenderer]
    def get(self, request, pk=None, format=None):
        id = pk
        if id is not None:
            prod = TaskFieldMaster.objects.get(id=id)
            serializer = TaskFieldMasterSerializer(prod)
            return Response(serializer.data)
        prod = TaskFieldMaster.objects.all()
        serializer = TaskFieldMasterSerializer(prod, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        serializer = TaskFieldMasterSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            return Response({'msg': 'Created'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UpdateTaskFieldMasterView(APIView):
    permission_classes = [IsAuthenticated]

    def get_object(self, pk):
        try:
            return TaskFieldMaster.objects(pk)
        except TaskFieldMaster.DoesNotExist:
            return Http404

    def get(self, request, pk, format=None):
        taskfieldmaster = self.get_object(pk)
        serializer = TaskFieldMasterSerializer(
            taskfieldmaster, data=request.data)
        return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk, format=None):
        taskfieldmaster = self.get_object(pk)
        serializer = TaskFieldMasterSerializer(
            taskfieldmaster, data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            return Response({'msg': 'Chenged'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        taskfieldmaster = self.get_object(pk)
        taskfieldmaster.delete()
        return Response({'msg': 'Delete'}, status=status.HTTP_204_NO_CONTENT)


# class TodoListApiView(APIView):
#     # add permission to check if user is authenticated
#     # permission_classes = [permissions.IsAuthenticated]

#     # 1. List all
#     def get(self, request, *args, **kwargs):
#         '''
#         List all the todo items for given requested user
#         '''
#         todos = Todo.objects.filter(user=request.user.id)
#         serializer = TodoSerializer(todos, many=True)
#         return Response(serializer.data, status=status.HTTP_200_OK)

#     # 2. Create
#     def post(self, request, *args, **kwargs):
#         '''
#         Create the Todo with given todo data
#         '''
#         data = {
#             'f_name': request.data.get('f_name'),
#             'f_msg1': request.data.get('f_msg1'),
#             'f_msg2': request.data.get('f_msg2'),
#             'f_note': request.data.get('f_note'),
#             # 'status': request.data.get('status'),
#             # 'task': request.data.get('task'),
#             # 'completed': request.data.get('completed'),

#             'user': request.user.id
#         }

#         serializer = TodoSerializer(data=data)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data, status=status.HTTP_201_CREATED)

#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# class TodoDetailApiView(APIView):
#     # add permission to check if user is authenticated
#     # permission_classes = [permissions.IsAuthenticated]

#     def get_object(self, todo_id, user_id):
#         '''
#         Helper method to get the object with given todo_id, and user_id
#         '''
#         try:
#             return Todo.objects.get(id=todo_id, user=user_id)
#         except Todo.DoesNotExist:
#             return None

#     # 3. Retrieve
#     def get(self, request, todo_id, *args, **kwargs):
#         '''
#         Retrieves the Todo with given todo_id
#         '''
#         todo_instance = self.get_object(todo_id, request.user.id)
#         if not todo_instance:
#             return Response(
#                 {"res": "Object with todo id does not exists"},
#                 status=status.HTTP_400_BAD_REQUEST
#             )

#         serializer = TodoSerializer(todo_instance)
#         return Response(serializer.data, status=status.HTTP_200_OK)

#     # 4. Update
#     def put(self, request, todo_id, *args, **kwargs):
#         '''
#         Updates the todo item with given todo_id if exists
#         '''
#         todo_instance = self.get_object(todo_id, request.user.id)
#         if not todo_instance:
#             return Response(
#                 {"res": "Object with todo id does not exists"},
#                 status=status.HTTP_400_BAD_REQUEST
#             )
#         data = {
#             'f_name': request.data.get('f_name'),
#             'f_msg1': request.data.get('f_msg1'),
#             'f_msg2': request.data.get('f_msg2'),
#             'f_note': request.data.get('f_note'),
#             # 'status': request.data.get('status'),
#             # 'task': request.data.get('task'),
#             # 'completed': request.data.get('completed'),
#             'user': request.user.id
#         }
#         serializer = TodoSerializer(
#             instance=todo_instance, data=data, partial=True)
#         if serializer.is_valid():
#             serializer.save()
#             return Response(serializer.data, status=status.HTTP_200_OK)
#         return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

#     # 5. Delete
#     def delete(self, request, todo_id, *args, **kwargs):
#         '''
#         Deletes the todo item with given todo_id if exists
#         '''
#         todo_instance = self.get_object(todo_id, request.user.id)
#         if not todo_instance:
#             return Response(
#                 {"res": "Object with todo id does not exists"},
#                 status=status.HTTP_400_BAD_REQUEST
#             )
#         todo_instance.delete()
#         return Response(
#             {"res": "Object deleted!"},
#             status=status.HTTP_200_OK
#         )
