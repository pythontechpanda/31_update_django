from django.db import models
from django.contrib.auth.models import BaseUserManager, AbstractBaseUser


#  Custom User Manager
class UserManager(BaseUserManager):
    def create_user(self, email, company, user_code, username, user_category, inactive, note, admin_access,
                    last_update_user, last_update_task, last_update_ip,menugroup1, menugroup2,
                    password=None, password2=None):
        """
        Creates and saves a User with the given email, name, tc and password.
        """
        if not email:
            raise ValueError('User must have an email address')

        user = self.model(
            email=self.normalize_email(username),
            user_code=user_code,
            company=company,
            username=username,
            note=note,
            user_category=user_category,
            admin_access=admin_access,
            last_update_user=last_update_user,
            last_update_task=last_update_task,
            last_update_ip=last_update_ip,
            inactive=inactive,
            menugroup1=menugroup1,
            menugroup2=menugroup2,

        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, company, user_code, username, user_category, inactive, note, admin_access,
                    last_update_user, last_update_task, last_update_ip,menugroup1, menugroup2, password=None):
        """
        Creates and saves a superuser with the given email, name, tc and password.
        """
        user = self.create_user(
            email,
            password=password,
            user_code=user_code,
            company=company,
            username=username,
            note=note,
            user_category=user_category,
            admin_access=admin_access,
            last_update_user=last_update_user,
            last_update_task=last_update_task,
            last_update_ip=last_update_ip,
            inactive=inactive,
            menugroup1=menugroup1,
            menugroup2=menugroup2,

        )
        user.is_admin = True
        user.save(using=self._db)
        return user


#  Custom User Model
class User(AbstractBaseUser):
    email = models.EmailField(
        verbose_name='Email',
        max_length=255,
        unique=True,
    )
    company = models.CharField(max_length=25)
    user_code = models.CharField(max_length=25)
    username = models.CharField(max_length=100, unique=True)
    user_category = models.CharField(max_length=25)
    admin_access = models.BooleanField()
    note = models.CharField(max_length=55, blank=True, null=True)
    password = models.CharField(max_length=100)
    inactive = models.BooleanField(default=True)
    last_update_user = models.CharField(max_length=25)
    last_update_task = models.CharField(max_length=25)
    last_update_ip = models.CharField(max_length=25)
    last_update_date = models.DateTimeField(auto_now_add=True)
    last_update_time = models.DateTimeField(auto_now=True)
    is_admin = models.BooleanField(default=False)
    is_staff = models.BooleanField(default=True)
    menugroup1 = models.CharField(max_length=100, blank=True, null=True)
    menugroup2 = models.CharField(max_length=100, blank=True, null=True)
    objects = UserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email', 'user_code', 'company', 'note','inactive',
                       'last_update_user','last_update_task','last_update_ip','user_category','admin_access','menugroup1', 'menugroup2']

    def __str__(self):
        return self.email
    # return self.get_username

    def has_perm(self, perm, obj=None):
        "Does the user have a specific permission?"
        # Simplest possible answer: Yes, always
        return self.is_admin

    def has_module_perms(self, app_label):
        "Does the user have permissions to view the app `app_label`?"
        # Simplest possible answer: Yes, always
        return True

    @property
    def is_staff(self):
        "Is the user a member of staff?"
        # Simplest possible answer: All admins are staff
        return self.is_admin


class AddCompany(models.Model):
    name = models.CharField(max_length=120)

    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class AddUser(models.Model):
    name = models.CharField(max_length=120)

    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class AddUserCategory(models.Model):
    name = models.CharField(max_length=120)

    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Adminaccess(models.Model):
    name = models.CharField(max_length=120)

    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Last_update_user(models.Model):
    name = models.CharField(max_length=120)

    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Last_update_task(models.Model):
    name = models.CharField(max_length=120)

    # desc = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class MenuGroupMaster(models.Model):
    group_name = models.CharField(max_length=25)
    sequence = models.CharField(max_length=10)
    inactive = models.BooleanField(null=True)
    note = models.CharField(max_length=55, blank=True)

    def __str__(self):
        return self.group_name


class TaskMaster(models.Model):
    # task = models.ForeignKey(MenuMaster, on_delete=models.CASCADE)
    task = models.CharField(max_length=22)
    description = models.CharField(max_length=55, blank=True)
    pyname = models.CharField(max_length=30, blank=True)
    inactive = models.BooleanField(null=True)
    note = models.CharField(max_length=55, blank=True)
    last_update_user = models.CharField(max_length=25)
    last_update_task = models.CharField(max_length=25)
    last_update_ip = models.CharField(max_length=25, blank=True)
    last_update_date = models.DateTimeField(auto_now_add=True)
    last_update_time = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.task


class MenuMaster(models.Model):
    # group_name = models.ForeignKey(MenuGroupMaster, on_delete=models.CASCADE)
    group_name = models.CharField(max_length=30)
    menu_name = models.CharField(max_length=30)
    tasks = models.ForeignKey(TaskMaster, on_delete=models.CASCADE)
    # task = models.CharField(max_length=30,default=False)

    def __str__(self):
        return self.menu_name


class UserTaskAccess(models.Model):
    company = models.ForeignKey(AddCompany, on_delete=models.CASCADE)
    users = models.ForeignKey(AddUser, on_delete=models.CASCADE)
    task = models.ForeignKey(TaskMaster, on_delete=models.CASCADE)
    inactive = models.BooleanField(null=True)
    note = models.CharField(max_length=55, blank=True)
    view_access = models.BooleanField(null=True)
    add_access = models.BooleanField(null=True)
    edit_access = models.BooleanField(null=True)
    delete_access = models.BooleanField(null=True)
    inactive_access = models.BooleanField(null=True)
    last_update_user = models.CharField(max_length=25)
    last_update_task = models.CharField(max_length=25)
    last_update_date = models.DateTimeField(auto_now_add=True)
    last_update_time = models.DateTimeField(auto_now=True)
    last_update_ip = models.CharField(max_length=25, blank=True)

    def __str__(self):
        return self.note


class FieldMaster(models.Model):
    # user = models.ForeignKey(UserMaster, on_delete=models.CASCADE, blank=True, null=True)
    field = models.CharField(max_length=50)
    placeholder_message = models.CharField(max_length=100, blank=True)
    error_message = models.CharField(max_length=100, blank=True)
    inactive = models.BooleanField(null=True)
    note = models.CharField(max_length=55, blank=True)
    last_update_user = models.CharField(max_length=25)
    last_update_task = models.CharField(max_length=25)
    last_update_date = models.DateTimeField(auto_now_add=True)
    last_update_time = models.DateTimeField(auto_now=True)
    last_update_ip = models.CharField(max_length=25, blank=True)

    def __str__(self):
        return self.field


class TaskFieldMaster(models.Model):
    company = models.ForeignKey(AddCompany, on_delete=models.CASCADE, default=None)
    user = models.ForeignKey(AddUser, on_delete=models.CASCADE, default=None)
    task = models.ForeignKey(TaskMaster, on_delete=models.CASCADE, default=None)
    field = models.ForeignKey(FieldMaster, on_delete=models.CASCADE)
    restricted = models.BooleanField()
    inactive = models.BooleanField(null=True)
    note = models.CharField(max_length=55, blank=True)
    last_update_user = models.CharField(max_length=25)
    last_update_task = models.CharField(max_length=25)
    last_update_date = models.DateTimeField(auto_now_add=True)
    last_update_time = models.DateTimeField(auto_now=True)
    last_update_ip = models.CharField(max_length=25, blank=True)

    def __str__(self):
        return self.note
