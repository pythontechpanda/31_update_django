from django.contrib import admin
from account.models import User
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from account.models import AddCompany, AddUser, AddUserCategory, Adminaccess, MenuGroupMaster,MenuMaster, TaskMaster, \
    UserTaskAccess, FieldMaster, TaskFieldMaster, Last_update_task, Last_update_user


class UserModelAdmin(BaseUserAdmin):
    # The fields to be used in displaying the User model.
    # These override the definitions on the base UserModelAdmin
    # that reference specific fields on auth.User.
    list_display = ('id',  'company', 'user_code', 'username','email', 'user_category',
    'inactive', 'note', 'is_admin','admin_access', 'last_update_user', 'last_update_date', 'last_update_time', 'last_update_task', 'last_update_ip')
    list_filter = ('is_admin',)
    fieldsets = (
        ('User Credentials', {'fields': ('username', 'password')}),
        ('Personal info', {'fields': ('email', 'inactive', 'note')}),
        ('Permissions', {'fields': ('is_admin',)}),
    )

    # list_editable = ('username', 'note','last_update_user',)

    # add_fieldsets is not a standard ModelAdmin attribute. UserModelAdmin
    # overrides get_fieldsets to use this attribute when creating a user.
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('company', 'user_code', 'username', 'password1', 'password2', 'email', 'user_category', 'inactive', 'note','admin_access','last_update_user','last_update_task','last_update_ip'),
        }),
    )
    search_fields = ('email',)
    ordering = ('email', 'id')
    filter_horizontal = ()


# For Company...


class MenuGroupMasterAdmin(admin.ModelAdmin):
    list_display = ['group_name', 'sequence', 'inactive', 'note']


class MenuMasterAdmin(admin.ModelAdmin):
    list_display = ['group_name', 'menu_name', 'tasks']


class TaskMasterAdmin(admin.ModelAdmin):
    list_display = ['task', 'description', 'pyname', 'inactive', 'note']


class FieldMasterAdmin(admin.ModelAdmin):
    list_display = ['field', 'placeholder_message', 'error_message', 'inactive',
                    'note']


class TaskFieldMasterAdmin(admin.ModelAdmin):
    list_display = ['company','user','task','field', 'restricted', 'inactive',
                    'note', 'last_update_user', 'last_update_task', 'last_update_ip']


class UserTaskAccessAdmin(admin.ModelAdmin):
    list_display = ['company', 'users', 'task', 'inactive',
                    'note', 'view_access', 'add_access', 'edit_access', 'delete_access', 'inactive_access',
                    'last_update_user', 'last_update_task', 'last_update_ip']


# Now register the new UserModelAdmin...
admin.site.register(User, UserModelAdmin)

admin.site.register(MenuGroupMaster, MenuGroupMasterAdmin)
admin.site.register(MenuMaster, MenuMasterAdmin)
admin.site.register(TaskMaster, TaskMasterAdmin)
admin.site.register(UserTaskAccess, UserTaskAccessAdmin)
admin.site.register(FieldMaster, FieldMasterAdmin)
admin.site.register(TaskFieldMaster, TaskFieldMasterAdmin)
# admin.site.register(AddUserCategory)
# admin.site.register(AddCompany)
# admin.site.register(AddUser)
# admin.site.register(Adminaccess)
